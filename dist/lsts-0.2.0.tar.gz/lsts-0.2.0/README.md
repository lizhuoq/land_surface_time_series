## Install
![install](pics/lsts_example_1.gif)
## Quick Start
![quick start](pics/lsts_example_2.gif)
